import os
import argparse
import logging
from pathlib import Path

import pandas as pd
import numpy as np
import torch

from models.experimental import attempt_load
from utils.datasets import LoadImages
from utils.general import check_img_size, non_max_suppression, increment_path
from utils.torch_utils import select_device

def get_logits_yolo(opt, source = 'data/images', weights = 'yolov5s.pt', project = 'output_test', name = 'test', conf_thres = 0.25, iou_thres = 0.45):

    ## TODO: Change
    project = opt.results_path
    name = opt.name

    ## Fixed
    imgsz = 640
    exist_ok = False
    device = ''
    augment = False
    classes = None
    agnostic_nms = False

    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    save_dir.mkdir(parents=True, exist_ok=True)  # make dir

    # Initialize
    device = select_device(device)
    half = device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    model = attempt_load(weights, map_location=device)  # load FP32 model
    stride = int(model.stride.max())  # model stride
    imgsz = check_img_size(imgsz, s=stride)  # check img_size
    labels = model.module.names if hasattr(model, 'module') else model.names  # get class names

    if half:
        model.half()  # to FP16

    # Run inference
    if device.type != 'cpu':
        model(torch.zeros(1, 3, imgsz, imgsz).to(device).type_as(next(model.parameters())))  # run once

    # load distillation db images
    db_path = "/home/student/noel_aitor/distillation_db"
    programs = sorted(os.listdir(db_path))
    if '.cat' in programs: programs.remove(".cat")

    df_tv3 = pd.DataFrame()
    logging.basicConfig(filename='../logs/run_yolo.log',
                        format='%(asctime)s - %(message)s', level=logging.INFO)

    logging.info('Starting to extract logits from distillation db')

    for i, program in enumerate(programs):
        chapters = sorted(os.listdir(os.path.join(db_path, program)))
        for chapter in chapters:
            # Set Dataloader
            dataset = LoadImages(os.path.join(db_path, program, chapter), img_size=imgsz, stride=stride)
            for path, img, im0s, vid_cap in dataset:
                img = torch.from_numpy(img).to(device)
                img = img.half() if half else img.float()  # uint8 to fp16/32
                img /= 255.0  # 0 - 255 to 0.0 - 1.0
                if img.ndimension() == 3:
                    img = img.unsqueeze(0)

                pred, logits = model(img, augment=augment)
                logits = torch.cat([l.reshape((torch.prod(torch.tensor(l.shape[:-1])), l.shape[-1])) for l in logits])
                logits_max = logits[:,5:].max(dim=0).values
                logits_mean = logits[:,5:].mean(dim=0)
                logits_min = logits[:,5:].min(dim=0).values

                max_pred = pred[0][:, 5:].max(axis=0)[0].tolist() # obtain max value of class for all possible boxes

                # Apply NMS
                [pred, max_conf] = non_max_suppression(pred, conf_thres, iou_thres, classes=classes,
                                                              agnostic=agnostic_nms)

                conf_det = np.zeros(80)
                for i, obj in enumerate(pred[0][:, -1].tolist()):
                    conf_det[int(obj)] = pred[0][i].tolist()[-2]

                df_tv3 = df_tv3.append({
                    "program": program,
                    "chapter": chapter,
                    "frame": path.split('/')[-1],
                    "logit_max": logits_max.tolist(),
                    "logit_mean": logits_mean.tolist(),
                    "logit_min": logits_min.tolist(),
                    "max_pred": max_pred,
                    "max_conf": max_conf,
                    "conf_det": conf_det
                }, ignore_index=True)

        logging.info(f'Logits from {program} extracted. {i + 1}/{len(programs)} completed')
    logging.info(f'Extracted logits from ALL programs. Creating csv file...')
    df_tv3.to_pickle("../logitsYoloFinal.csv")
    logging.info(f"Logits stored in the csv!")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, default='yolov5l.pt')
    parser.add_argument('--source', type=str, default='data/images')  # file/folder, 0 for webcam
    parser.add_argument('--results_path', default='/home/student/noel_aitor/results_yolo/', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--log', default=False)
    args = vars(parser.parse_args())
    opt = parser.parse_args()

    with torch.no_grad():
        if opt.update:  # update all models (to fix SourceChangeWarning)
            for opt.weights in ['yolov5s.pt', 'yolov5m.pt', 'yolov5l.pt', 'yolov5x.pt']:
                get_logits_yolo(
                    opt,
                    weights=args['weights'],
                    project='output_test',
                    name='test',
                    conf_thres=0.25,
                    iou_thres=0.45
                )
                strip_optimizer(opt.weights)
        else:
            get_logits_yolo(
                opt,
                weights=args['weights'],
                project='output_test',
                name='test',
                conf_thres=0.25,
                iou_thres=0.45
            )
